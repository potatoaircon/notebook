# TSUGAIKE STAY MAP — January 2027

## What is included
- `index.html`: a working standalone preview. Its DEC page is **only a placeholder**.
- `tsugaike-map.css`: isolated styles for the month selector and January map.
- `tsugaike-map.js`: month selector, hotel pins, compact cards, click-away closing, route highlight.

## Integration into the EXISTING `notebook` project
1. **Do not replace your existing `index.html` with this demo**. Keep all current December HTML, styling, JavaScript, maps, and detail views intact.
2. Copy the two `.css` / `.js` files into the existing project and link them in the existing `<head>` and before `</body>` respectively.
3. Add `id="tm-december"` to the outermost wrapper that encompasses the entire **December homepage/detail UI** (not the whole `<body>`). If no wrapper exists, wrap that UI with `<div id="tm-december"> ... </div>`.
4. Copy `<nav id="tm-switch">...</nav>` and `<section id="tm-january">...</section>` from the demo into the existing `index.html` as siblings of `#tm-december`.
5. Preserve existing December JavaScript and navigation. Month switching is only at the home-level. If December detail page is open, use its existing back flow before switching months, or have Cursor integrate a safe close-detail function.
6. Confirm Safari mobile gesture back, DEC map, hover/touch cards, routes, and detail pages all still work.
7. January hotel pins are **placeholder examples**, NOT confirmed properties or geographically accurate placements. Do not publish fabricated names, prices, walking times or coordinates as facts. Replace entries in `hotels` in JS after user provides property names and verified walking routes.
8. Do not attempt to fetch Booking/Agoda pricing automatically. Add manual prices only from dated screenshots.

## Suggested Cursor instruction
Integrate the included `tsugaike-map` files into my existing GitHub Pages `notebook` project without replacing my current index.html. Add a fixed DEC / JAN month selector on the top-right of the homepage. Default DEC. DEC must preserve all existing behaviors and layouts. JAN displays the included SVG illustration and hotel cards, with placeholder hotels until I provide verified names, coordinates, walking distances, prices, and links. Do not invent actual hotel information. On mobile preserve tap-outside closing and existing December Safari back navigation. Test both months at 390px mobile and desktop. The January illustration is a stylized, not geographic, map. Do not change December artwork, transport details, or hotel data.
